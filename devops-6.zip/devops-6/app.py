print("ai model rinning")
